function setup() {
  createCanvas(640, 480);
}

function draw() {
  if (mouseIsPressed) {
    ellipse(mouseX, mouseY, 50, 50); fill(255, 79, 79); noStroke()

  }

}